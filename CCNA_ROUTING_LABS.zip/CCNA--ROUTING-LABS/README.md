# CCNA ROUTING LABS – Packet Tracer Projects

Welcome to my CCNA Routing Labs collection. These are hands-on Packet Tracer files designed to help students and professionals practice core routing concepts.

---

## 📂 Lab Categories

- **Static Routing**
  - [1-Static-Routing-Basic.pkt](Static-Routing/1-Static-Routing-Basic.pkt)

- **RIP (Routing Information Protocol)**
  - [1-RIPv2-SingleNetwork.pkt](RIP/1-RIPv2-SingleNetwork.pkt)

- **EIGRP (Enhanced Interior Gateway Routing Protocol)**
  - [1-EIGRP-Basic-Config.pkt](EIGRP/1-EIGRP-Basic-Config.pkt)

- **OSPF (Open Shortest Path First)**
  - [1-OSPF-Single-Area.pkt](OSPF/1-OSPF-Single-Area.pkt)

- **Inter-VLAN Routing**
  - [1-InterVLAN-Routing.pkt](InterVLAN/1-InterVLAN-Routing.pkt)

---

## 🧰 Tools Used
- Cisco Packet Tracer
- Cisco CLI
- Basic Switching & Routing
- Troubleshooting Techniques

---

## 👨‍🎓 Author
**Brian David Amai**  
CCNA Certified | Cybersecurity | NetDevOps | IoT | Network Technician

---

## 📜 License
MIT License – see [LICENSE](LICENSE)

---

## 🏅 Certifications
[Click here to view my badges and certifications](#)

---

> Star this repo if it helped you — more labs coming soon!
